<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $driver = DB::getDriverName();
        if ($driver !== 'mysql') {
            \Log::warning("Migration skipped: not MySQL.");
            return;
        }

        $dbName = DB::getDatabaseName();

        // Get all tables with a column named 'deleted_at'
        $deletedAtColumns = DB::select("
            SELECT table_name, column_name, is_nullable, column_type
            FROM information_schema.columns
            WHERE table_schema = ?
            AND column_name = 'deleted_at'
        ", [$dbName]);

        if (empty($deletedAtColumns)) {
            \Log::info("No tables with deleted_at column found.");
            return;
        }

        foreach ($deletedAtColumns as $col) {
            $col = (array) $col;
            $table = $col['table_name'] ?? $col['TABLE_NAME'] ?? null;
            $isNullable = $col['is_nullable'] ?? $col['IS_NULLABLE'] ?? null;
            $columnType = $col['column_type'] ?? $col['COLUMN_TYPE'] ?? null;

            if (!$table) {
                \Log::warning("Skipping column without table name.");
                continue;
            }
            if (!$columnType) {
                \Log::warning("Skipping {$table}.deleted_at: missing column type.");
                continue;
            }

            $safeTable = str_replace('`', '``', $table);

            // Step 1: Update zero-dates to NULL
            $zeroDateCount = DB::table($table)
                ->where(function ($query) {
                    $query->where('deleted_at', '0000-00-00 00:00:00')
                        ->orWhere('deleted_at', '0000-00-00');
                })
                ->count();

            if ($zeroDateCount > 0) {
                \Log::info("Updating {$zeroDateCount} zero-date records in table {$table}");
                DB::table($table)
                    ->where(function ($query) {
                        $query->where('deleted_at', '0000-00-00 00:00:00')
                            ->orWhere('deleted_at', '0000-00-00');
                    })
                    ->update(['deleted_at' => null]);
            }

            // Step 2: Alter column to allow NULL with default NULL
            try {
                if ($isNullable !== 'YES') {
                    DB::statement("ALTER TABLE `{$safeTable}` MODIFY `deleted_at` {$columnType} NULL DEFAULT NULL");
                    \Log::info("Altered deleted_at column to nullable in table {$table}");
                } else {
                    \Log::info("Skipped {$table}.deleted_at: already nullable");
                }
            } catch (\Exception $e) {
                \Log::error("Failed to alter deleted_at column in table {$table}: " . $e->getMessage());
            }
        }
    }

    public function down(): void
    {
        \Log::info("Down migration skipped: cannot safely revert NULLs to zero-date or revert column changes.");
    }
};

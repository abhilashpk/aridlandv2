<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $driver = DB::getDriverName();
        if ($driver !== 'mysql') {
            \Log::warning("Migration skipped: not MySQL.");
            return;
        }

        $dbName = DB::getDatabaseName();

        $deletedAtColumns = DB::select("
            SELECT table_name, is_nullable, column_type
            FROM information_schema.columns
            WHERE table_schema = ?
              AND column_name = 'deleted_at'
        ", [$dbName]);

        if (empty($deletedAtColumns)) {
            \Log::info("No tables with deleted_at column found.");
            return;
        }

        foreach ($deletedAtColumns as $col) {
            $col = (array) $col;
            $table = $col['table_name'] ?? $col['TABLE_NAME'] ?? null;
            $isNullable = $col['is_nullable'] ?? $col['IS_NULLABLE'] ?? null;
            $columnType = $col['column_type'] ?? $col['COLUMN_TYPE'] ?? null;

            if (!$table || !$columnType) {
                \Log::warning("Skipping deleted_at column: missing table name or type.");
                continue;
            }

            $safeTable = str_replace('`', '``', $table);

            DB::table($table)
                ->where(function ($query) {
                    $query->where('deleted_at', '0000-00-00 00:00:00')
                        ->orWhere('deleted_at', '0000-00-00');
                })
                ->update(['deleted_at' => null]);

            if ($isNullable !== 'YES') {
                DB::statement("ALTER TABLE `{$safeTable}` MODIFY `deleted_at` {$columnType} NULL DEFAULT NULL");
            }
        }
    }

    public function down(): void
    {
        \Log::info("Down migration skipped: cannot safely revert NULLs to zero-date.");
    }
};

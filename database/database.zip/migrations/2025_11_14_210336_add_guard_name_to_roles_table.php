<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasTable('roles') || Schema::hasColumn('roles', 'guard_name')) {
            return;
        }
        Schema::table('roles', function (Blueprint $table) {
            // Spatie requires guard_name
            $table->string('guard_name')->default('web')->after('name');
        });
    }

    public function down(): void
    {
        if (!Schema::hasTable('roles') || !Schema::hasColumn('roles', 'guard_name')) {
            return;
        }
        Schema::table('roles', function (Blueprint $table) {
            $table->dropColumn('guard_name');
        });
    }
};

<?php namespace App\Repositories\PurchaseEnquiry;

use App\Interfaces\RepositoryInterface;

Interface PurchaseEnquiryInterface extends RepositoryInterface {
	
}

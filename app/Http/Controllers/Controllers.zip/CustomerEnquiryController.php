<?php

namespace App\Http\Controllers;
use App\Repositories\Area\AreaInterface;
use App\Repositories\Itemmaster\ItemmasterInterface;
use App\Repositories\Terms\TermsInterface;
use App\Repositories\Jobmaster\JobmasterInterface;
use App\Repositories\AccountMaster\AccountMasterInterface;
use App\Repositories\Currency\CurrencyInterface;
use App\Repositories\VoucherNo\VoucherNoInterface;
use App\Repositories\CustomerEnquiry\CustomerEnquiryInterface;
use App\Repositories\Salesman\SalesmanInterface;
use App\Repositories\Forms\FormsInterface;
use App\Repositories\Location\LocationInterface;

use Illuminate\Http\Request;

use App\Http\Requests;
use Session;
use Response;
use Input;
use Excel;
use App;
use DB;
use Mail;
use Auth;
use PDF;

class CustomerEnquiryController extends Controller
{

	protected $area;
	protected $itemmaster;
	protected $terms;
	protected $jobmaster;
	protected $accountmaster;
	protected $currency;
	protected $voucherno;
	protected $customer_enquiry;
	protected $salesman;
	protected $forms;
	protected $formData;
	protected $location;
	
	public function __construct(CustomerEnquiryInterface $customer_enquiry, ItemmasterInterface $itemmaster, TermsInterface $terms, JobmasterInterface $jobmaster, AccountMasterInterface $accountmaster, CurrencyInterface $currency, VoucherNoInterface $voucherno, AreaInterface $area, SalesmanInterface $salesman,FormsInterface $forms,LocationInterface $location) {
		
		parent::__construct( App::make('App\Repositories\Parameter1\Parameter1Interface'), App::make('App\Repositories\VatMaster\VatMasterInterface') );
		
		$this->middleware('auth');
		$this->area = $area;
		$this->itemmaster = $itemmaster;
		$this->terms = $terms;
		$this->jobmaster = $jobmaster;
		$this->accountmaster = $accountmaster;
		$this->currency = $currency;
		$this->voucherno = $voucherno;
		$this->customer_enquiry = $customer_enquiry;
		$this->salesman = $salesman;
		$this->forms = $forms;
		$this->formData = $this->forms->getFormData('CE');
		$this->location = $location;
		if(Auth::user()->roles[0]->name=='Salesman') {
		    $srec = DB::table('salesman')->where('name',Auth::user()->name)->select('id')->first();
		    if($srec)
		        Session::put('salesman_id',$srec->id);
		}
		
	}
	
    public function index() {
		
		$data = array();
		$quotations = [];//$this->customer_enquiry->quotationSalesList();//echo '<pre>';print_r($quotations);exit;
		$salesmans = $this->salesman->getSalesmanList();
         $cus =DB::table('account_master')->where('category','CUSTOMER')->where('status',1)->where('deleted_at','0000-00-00 00:00:00')->select('id','master_name')->get(); 
		$jobs = $this->jobmaster->activeJobmasterList();
		return view('body.customerenquiry.index')
					->withQuotations($quotations)
					->withSalesman($salesmans)
					->withJobs($jobs)
					->withCus($cus)
					->withSettings($this->acsettings)
					->withData($data);
	}
	
	public function ajaxPaging(Request $request)
	{
		$columns = array( 
                            0 =>'customer_enquiry.id', 
                            1 =>'voucher_no',
                            2=> 'voucher_date',
                            3=> 'customer',
							4=> 'net_total'
                        );
						
		$totalData = $this->customer_enquiry->salesEstimateListCount();
            
        $totalFiltered = $totalData; 

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = 'customer_enquiry.id';
        $dir = 'desc';
		$search = (empty($request->input('search.value')))?null:$request->input('search.value');
        
		$invoices = $this->customer_enquiry->salesEstimateList('get', $start, $limit, $order, $dir, $search);
		
		if($search)
			$totalFiltered =  $this->customer_enquiry->salesEstimateList('count', $start, $limit, $order, $dir, $search);
		
        $data = array();
        if(!empty($invoices))
        {
           
			foreach ($invoices as $row)
            {
                $edit =  '"'.url('customer_enquiry/edit/'.$row->id).'"';
                $delete =  'funDelete("'.$row->id.'","'.$row->is_editable.'")';
				$print = url('customer_enquiry/print/'.$row->id);
				$open =  '"'.url('customer_enquiry/doc_open/'.$row->id).'"';
				
                $nestedData['id'] = $row->id;
                $nestedData['voucher_no'] = $row->voucher_no;
				$nestedData['voucher_date'] = date('d-m-Y', strtotime($row->voucher_date));
				$nestedData['customer'] = ($row->customer=='CASH CUSTOMERS') ? (($row->customer_name!='')?$row->customer.'('.$row->customer_name.')':$row->customer) : $row->customer;
				$nestedData['net_total'] = $row->net_total;
                $nestedData['edit'] = "<p><button class='btn btn-primary btn-xs' onClick='location.href={$edit}'>
												<span class='glyphicon glyphicon-pencil'></span></button></p>";
				
												
				$nestedData['open'] = "<p><button class='btn btn-success btn-xs'  onClick='location.href={$open}' target='_blank'>
												<i class='fa fa-fw fa-folder-open'></i></button></p>";
													
				$nestedData['delete'] = "<button class='btn btn-danger btn-xs delete' onClick='{$delete}'>
												<span class='glyphicon glyphicon-trash'></span>";
												
				$apr = ($this->acsettings->doc_approve==1)?[1]:[0,1,2];
				if(in_array($row->doc_status, $apr))	 {
					if($row->is_fc==1) {
						$nestedData['print'] = "<p><a href='{$print}' target='_blank' class='btn btn-primary btn-xs'><span class='fa fa-fw fa-print'></span></a>
												<a href='{$print}/FC' target='_blank' class='btn btn-primary btn-xs'><span class='fa fa-fw fa-print'></span>FC</a></p>";
					} else 
						$nestedData['print'] = "<p><a href='{$print}' target='_blank' class='btn btn-primary btn-xs'><span class='fa fa-fw fa-print'></span></a></p>";
				} else {
					$nestedData['print'] = "";
				}
				
				if($this->acsettings->doc_approve==1) {
					if($row->doc_status==1)
						$status = '<span class="label label-sm label-success">Approved</span>';
					else if($row->doc_status==0)
						$status = '<span class="label label-sm label-warning">Pending</span>';
					else if($row->doc_status==2)
						$status = '<span class="label label-sm label-danger">Rejected</span>';
					
					$nestedData['status'] = $status;
				} else 
					$nestedData['status'] = '';
				
                $data[] = $nestedData;

            }
        }
          
        $json_data = array(
                    "draw"            => intval($request->input('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $data   
                    );
            
        echo json_encode($json_data);
	}
	
	public function docopen($id) { 
		$data = array();
		$orderrow = $this->customer_enquiry->findPOdata($id);
		$orditems = $this->customer_enquiry->getItems($id);
		$photos = DB::table('enq_fotos')->where('enq_id',$id)->get(); 
		$val = '';
		foreach($photos as $row) {
			$val .= ($val=='')?$row->photo:','.$row->photo;
		}	
		return view('body.customerenquiry.open')
					->withPhotos($val)
					->withFormdata($this->formData)
					->withOrderrow($orderrow)
					->withOrditems($orditems)
				->withData($data);

	}

	public function add($id = null) {

		$data = array();
		$itemmaster = $this->itemmaster->activeItemmasterList();
		$terms = $this->terms->activeTermsList();
		$jobs = $this->jobmaster->activeJobmasterList();
		$currency = $this->currency->activeCurrencyList();
		$res = $this->voucherno->getVoucherNo('CE');
		//$vno = $res->no;//echo '<pre>';print_r($currency);exit;
		$location = $this->location->locationList();
		$row = DB::table('customer_enquiry')->where('status',1)->where('deleted_at','0000-00-00 00:00:00')->orderBy('id','DESC')->select('doc_status','id')->first();
		$apr = ($this->acsettings->doc_approve==1)?[1]:[0,1,2];
		if($row && in_array($row->doc_status, $apr))
			$lastid = $row->id;
		else
			$lastid = null;
		
		$leadrow = null;
		
		if($id) {
			$leadrow = DB::table('leads')->where('leads.id',$id)
							->join('account_master', 'account_master.id','=','leads.customer_id')
							->leftJoin('salesman', 'salesman.id','=','leads.salesman_id')
							->select('leads.id','leads.customer_id','account_master.master_name','leads.salesman_id','salesman.name','leads.lead_no')
							->first(); //echo '<pre>';print_r($leadrow);exit;
		}
		
		return view('body.customerenquiry.add')
					->withItems($itemmaster)
					->withTerms($terms)
					->withJobs($jobs)
					->withCurrency($currency)
					->withVoucherno($res)
					->withVatdata($this->vatdata)
					->withSettings($this->acsettings)
					->withPrintid($lastid)
					->withVoucherdt(Session::get('voucher_date'))
					->withLpodt(Session::get('lpo_date'))
					->withFormdata($this->formData)
					->withLrow($leadrow)
					->withLocation($location)
					->withData($data);
	}
	
	public function save(Request $request) { //
		//echo '<pre>';print_r( Input::all() );exit;
		
		/* $this->validate($request, [
        'reference_no' => 'required', 'voucher_date' => 'required','item_code.*' => 'required'
    ]); */
		if( $this->validate(
			$request, 
			[//'reference_no' => 'required',
			 'customer_name' => 'required','customer_id' => 'required',
			 'item_code.*'  => 'required', 'item_id.*' => 'required',
			 'unit_id.*' => 'required',
			 'quantity.*' => 'required',
			 'cost.*' => 'required'
			],
			[//'reference_no.required' => 'Reference no. is required.',
			 'customer_name.required' => 'Customer Name is required.','customer_id.required' => 'Customer name is invalid.',
			 'item_code.*.required'   => 'Item code is required.', 'item_id.*' => 'Item code is invalid.',
			 'unit_id.*' => 'Item unit is required.',
			 'quantity.*' => 'Item quantity is required.',
			 'cost.*' => 'Item cost is required.'
			]
		)) {
			//echo '<pre>';print_r($request->flash());exit;
			return redirect('customer_enquiry/add')->withInput()->withErrors();
		}
		
		$id = $this->customer_enquiry->create(Input::all());
	
		if($id) {
			Session::flash('message', 'Customer Enquiry added successfully.'); 
			return redirect('customer_enquiry/add');
			
		} else {
			Session::flash('error', 'Something went wrong, Order failed to add!');
			return redirect('customer_enquiry/add');
		}
		
		
	}
	
	public function destroy($id)
	{
		$this->customer_enquiry->delete($id);
		//check accountmaster name is already in use.........
		// code here ********************************
		Session::flash('message', 'Customer Enquiry deleted successfully.');
		return redirect('customer_enquiry');
	}
	
	public function checkRefNo() {

		$check = $this->customer_enquiry->check_reference_no(Input::get('reference_no'), Input::get('id'));
		$isAvailable = ($check) ? false : true;
		echo json_encode(array(
							'valid' => $isAvailable,
						));
	}
	
	private function makeTreeArr($result) {
		
		$childs = array();
		foreach($result as $item)
			$childs[$item->item_detail_id][] = $item;
		
		return $childs;
	}
	
	private function createItem($row) {
		
	  DB::beginTransaction();
	  try {
		
		//GET category
		if($row->category!='') {
			$cat = DB::table('category')->where( function ($query) use($row) {
											$query->where('category_name', '=', $row->category)
											  ->orWhere('description', '=', $row->category);
									})->select('id')->first();
							   
			if(!$cat) { //IF category NOT EXIST...
				$category_id = DB::table('category')->insertGetId(['category_name' => strtoupper($row->category),'description' => strtoupper($row->category),'status' => 1]);
			} else
				$category_id = $cat->id;
		} else 
			$category_id = '';
		
		//GET subcategory
		if($row->subcategory!='') {
			$subcat = DB::table('category')->where( function ($query) use($row) {
											$query->where('category_name', '=', $row->subcategory)
											  ->orWhere('description', '=', $row->subcategory);
									})->select('id')->first();
							   
			if(!$subcat) { //IF category NOT EXIST...
				$subcategory_id = DB::table('category')->insertGetId(['category_name' => strtoupper($row->subcategory),'description' => strtoupper($row->subcategory), 'parent_id' => $category_id, 'status' => 1]);
			} else
				$subcategory_id = $subcat->id;
		} else 
			$subcategory_id = '';
		
		
		//GET group
		if($row->group!='') {
			$grp = DB::table('groupcat')->where( function ($query) use($row) {
											$query->where('group_name', '=', $row->group)
											  ->orWhere('description', '=', $row->group);
									})->select('id')->first();
							   
			if(!$grp) { //IF groupcat NOT EXIST...
				$group_id = DB::table('groupcat')->insertGetId(['group_name' => strtoupper($row->group),'description' => strtoupper($row->group),'status' => 1]);
			} else
				$group_id = $grp->id;
		} else 
			$group_id = '';
		
		
		//GET subgroup
		if($row->subgroup!='') {
			$subgrp = DB::table('groupcat')->where( function ($query) use($row) {
											$query->where('group_name', '=', $row->subgroup)
											  ->orWhere('description', '=', $row->subgroup);
									})->select('id')->first();
							   
			if(!$subgrp) { //IF subgroupcat NOT EXIST...
				$subgroup_id = DB::table('groupcat')->insertGetId(['group_name' => strtoupper($row->subgroup),'description' => strtoupper($row->subgroup), 'parent_id' => $group_id, 'status' => 1]);
			} else
				$subgroup_id = $subgrp->id;
		} else 
			$subgroup_id = '';
		
		$insert = ['item_code' => $row->item_code, 
									 'description' => $row->description,
									 'class_id' => 1,
									 'group_id' => $group_id,
									 'subgroup_id' => $subgroup_id,
									 'category_id' => $category_id,
									 'subcategory_id' => $subcategory_id,
									 'status'   => 1,
									 'created_at' => date('Y-m-d H:i:s')
								  ];
								  
		
		//GET UNIT ID
		if($row->unit!='') {
			$unit = DB::table('units')->where('unit_name', strtoupper($row->unit))->select('id','unit_name')->first();
			if(!$unit) { //IF UNIT NOT EXIST...
				$unit_id = DB::table('units')->insertGetId(['unit_name' => strtoupper($row->unit),'description' => strtoupper($row->unit),'status' => 1]);
				$unit_name = strtoupper($row->unit);
			} else {
				$unit_id = $unit->id;
				$unit_name = $unit->unit_name;
			}
		} else {
			$unit = DB::table('units')->where('unit_name', 'NOS')->select('id','unit_name')->first();
			$unit_id = $unit->id;
			$unit_name = $unit->unit_name;
		}
		//echo '<pre>';print_r($insert);exit;
		$item_id = DB::table('itemmaster')->insertGetId($insert);
		DB::table('item_unit')->insert(['itemmaster_id' => $item_id,
										'unit_id' => $unit_id,
										'packing' => strtoupper($unit_name),
										//'opn_quantity' => ($row->quantity=='')?0:$row->quantity,
										//'opn_cost' => ($row->cost_avg=='')?0:$row->cost_avg,
										//'sell_price' => ($row->sales_price=='')?0:$row->sales_price,
										'vat' => 5,
										'status' => 1,
										//'cur_quantity' => ($row->quantity=='')?0:$row->quantity,
										'is_baseqty' => 1
										//'received_qty' => ($row->quantity=='')?0:$row->quantity
										//'cost_avg' => ($row->cost_avg=='')?0:$row->cost_avg
										]);
										
		DB::table('item_log')->insert([
								'document_type' => 'OQ',
								'document_id' => 0,
								'item_id' => $item_id,
								'unit_id' => $unit_id,
								'trtype' => 1,
								'packing' => 1,
								'status' => 1,
								'created_at' => date('Y-m-d H:i:s'),
								'voucher_date' => date('Y-m-d')
								]);
		 DB::commit();
		 return $item = (object)['item_id' => $item_id, 'item_code' => $row->item_code, 'item_name' => $row->description, 'unit_id' => $unit_id, 'unit_name' => $unit_name, 'vat' => 5, 'quantity' => $row->quantity, 'cost' => $row->rate,'opn_cost' => $row->rate];
		
	  } catch(\Exception $e) { 
		
			DB::rollback(); echo $e->getLine().' - '.$e->getMessage();exit;
			return false;
		}
						
						
	}	
	
	
	//EXCEL FORMAT:   Item Code|Description|Unit|Quantity|Rate
	public function getImport(Request $request,$id=null) {
		  //echo '<pre>';print_r($request->all());exit;
		if(Input::hasFile('import_file')){
			
			
			$locdefault = DB::table('location')->where('is_default',1)->where('status',1)->where('deleted_at','0000-00-00 00:00:00')->select('id')->first();

			$path = Input::file('import_file')->getRealPath();
			$data = Excel::load($path, function($reader) { })->get();
			//echo '<pre>';print_r($data);exit;
			//$items = array();
			foreach ($data as $row) {
				 if($row->item_code!='' && $row->description!='') {
					 //CHECK ITEM EXIST OR NOT
					$cost = ($row->rate!='')?DB::raw($row->rate.' AS cost'):0;
					 $item = DB::table('itemmaster')->where('itemmaster.item_code', '=', $row->item_code)
									->where( function ($query) use($row) {
										$query->where('itemmaster.item_code', '=', $row->item_code)
											  ->orWhere('itemmaster.description', '=', $row->description);
								   })
							   ->join('item_unit', 'item_unit.itemmaster_id', '=', 'itemmaster.id')
							   ->where('item_unit.is_baseqty',1)
							   ->select('itemmaster.id AS item_id','itemmaster.item_code','itemmaster.description AS item_name',
										'item_unit.unit_id','item_unit.packing AS unit_name','item_unit.vat','item_unit.opn_cost',
										DB::raw($row->quantity.' AS quantity'),'item_unit.last_purchase_cost AS cost')
							   ->first(); //echo '<pre>';print_r($item);exit;
						//$item->quantity = $row->quantity;	
						
						//$items = array_push($item,$itm);
						   
					//echo '<pre>';print_r($item);exit;
					 
					 if(!$item) {
						 $item = $this->createItem($row);
					 } else {
						 //if($item->cost==0 && $row->rate!='')
							$item->cost = ($row->rate!='')?$row->rate:0;
					 }
					 
					 $items[] = $item;
				 }
			}
			
		}
		
		$leadrow = null;
		
		if($id) {
			$leadrow = DB::table('leads')->where('leads.id',$id)
							->join('account_master', 'account_master.id','=','leads.customer_id')
							->leftJoin('salesman', 'salesman.id','=','leads.salesman_id')
							->select('leads.id','leads.customer_id','account_master.master_name','leads.salesman_id','salesman.name','leads.lead_no')
							->first(); //echo '<pre>';print_r($leadrow);exit;
		}
		
		$terms = $this->terms->activeTermsList();
		$jobs = $this->jobmaster->activeJobmasterList();
		$currency = $this->currency->activeCurrencyList();
		$location = $this->location->locationList();
		//$vouchers = $this->accountsetting->getAccountSettingsDefault2($vid=1);
		$voucherno = $this->voucherno->getVoucherNo('CE');
		$quoterow = (object)['voucher_id' => $request->input('voucher_id'),
						   'voucher_no' => $request->input('voucher_no'),
						   'curno' => $request->input('curno'),
						   'reference_no' => $request->input('reference_no'),
						   'voucher_date' => ($request->input('voucher_date')=='')?date('d-m-Y'):$request->input('voucher_date'),
						   'lpo_no' => $request->input('lpo_no'),
						   'lpo_date' => $request->input('lpo_date'),
						   'customer_name' => $request->input('customer_name'),
						   'customer_id' => $request->input('customer_id'),
						   'salesman_id' => $request->input('salesman_id'),
						   'description' => $request->input('description'),
						   'terms_id' => $request->input('terms_id'),
						   'job_id' => $request->input('job_id'),
						   'is_fc' => $request->input('is_fc'),
						   'currency_id' => $request->input('currency_id'),
						   'currency_rate' => $request->input('currency_rate'),
						   'location_id' => $request->input('location_id'),
						   //'po_no' => $request->input('po_no')
						  ];
						  
		//echo '<pre>';print_r($items);exit;
		
		return view('body.customerenquiry.additem')
						->withTerms($terms)
						->withJobs($jobs)
						->withCurrency($currency)
						->withQuoterow($quoterow)
						->withQuoteitems($items)
						->withLocation($location)
						->withVatdata($this->vatdata)
						->withSettings($this->acsettings)
						->withFormdata($this->formData)
						->withVoucherno($voucherno)
						->withLocdefault($locdefault)
						->withLrow($leadrow)
						->withData($data);
		
		
	}

	
	public function edit($id) { 

		$data = array();
		$itemmaster = $this->itemmaster->activeItemmasterList();
		$terms = $this->terms->activeTermsList();
		$jobs = $this->jobmaster->activeJobmasterList();
		$currency = $this->currency->activeCurrencyList();
		$orderrow = $this->customer_enquiry->findPOdata($id);
		$orditems = $this->customer_enquiry->getItems($id);
		$itemdesc = $this->makeTreeArr($this->customer_enquiry->getItemDesc($id));//echo '<pre>';print_r($itemdesc);exit;
		$photos = DB::table('enq_fotos')->where('enq_id',$id)->get(); 
		$val = '';
		foreach($photos as $row) {
			$val .= ($val=='')?$row->photo:','.$row->photo;
		}		
		$apr = ($this->acsettings->doc_approve==1)?[1]:[0,1,2];
		if(in_array($orderrow->doc_status, $apr))
			$isprint = true;
		else
			$isprint = null;
		
		return view('body.customerenquiry.edit')
					->withItems($itemmaster)
					->withTerms($terms)
					->withJobs($jobs)
					->withCurrency($currency)
					->withOrderrow($orderrow)
					->withOrditems($orditems)
					->withItemdesc($itemdesc)
					->withPhotos($val)
					->withVatdata($this->vatdata)
					->withSettings($this->acsettings)
					->withFormdata($this->formData)
					->withIsprint($isprint)
					->withData($data);

	}
	
	public function update(Request $request)
	{	
		//echo '<pre>';print_r(Input::all());exit;
		$id = $request->input('quotation_order_id');
		if( $this->validate(
			$request, 
			[//'reference_no' => 'required',
			 'customer_name' => 'required','customer_id' => 'required',
			 'item_code.*'  => 'required', 'item_id.*' => 'required',
			 'unit_id.*' => 'required',
			 'quantity.*' => 'required',
			 'cost.*' => 'required'
			],
			[//'reference_no.required' => 'Reference no. is required.',
			 'customer_name.required' => 'Customer Name is required.','customer_id.required' => 'Customer name is invalid.',
			 'item_code.*.required'   => 'Item code is required.', 'item_id.*' => 'Item code is invalid.',
			 'unit_id.*' => 'Item unit is required.',
			 'quantity.*' => 'Item quantity is required.',
			 'cost.*' => 'Item cost is required.'
			]
		)) {
			//echo '<pre>';print_r($request->flash());exit;
			return redirect('customer_enquiry/edit/'.$id)->withInput()->withErrors();
		}
		
		$this->customer_enquiry->update($id, Input::all()); 
		
		########## email script #############
		if($this->acsettings->doc_approve==1 && Input::get('doc_status')==1 && Input::get('chkmail')==1) {
 
			$attributes['document_id'] = $id;
			$attributes['is_fc'] = '';
			$result = $this->customer_enquiry->getQuotation($attributes);
			$itemdesc = $this->makeTreeArr($this->customer_enquiry->getItemDesc($id));
			$titles = ['main_head' => 'Customer Enquiry','subhead' => 'Customer Enquiry'];
			$data = array('details'=> $result['details'], 'titles' => $titles, 'fc' => $attributes['is_fc'], 'itemdesc' => $itemdesc, 'items' => $result['items']);
			$pdf = PDF::loadView('body.customerenquiry.pdfprint', $data);
			
			$mailmessage = Input::get('email_message');
			$emails = explode(',', Input::get('email'));
			
			if($emails[0]!='') {
				$data = array('name'=> Input::get('customer_name'), 'mailmessage' => $mailmessage );
				try{
					Mail::send('body.customerenquiry.email', $data, function($message) use ($emails,$pdf) {
						$message->to($emails[0]);
						
						if(count($emails) > 1) {
							foreach($emails as $k => $row) {
								if($k!=0)
									$cc[] = $row;
							}
							$message->cc($cc);
						}
						
						$message->subject('Customer Enquiry');
						$message->attachData($pdf->output(), "enquiry.pdf");
					});
					
				}catch(JWTException $exception){
					$this->serverstatuscode = "0";
					$this->serverstatusdes = $exception->getMessage();
					echo '<pre>';print_r($this->serverstatusdes);exit;
				}
			}
		}
		
		Session::flash('message', 'Customer Enquiry sales updated successfully');
		return redirect('customer_enquiry');
	}
	
	public function ajax_getcode($group_id)
	{
		$group = $this->group->getGroupCode($group_id);
		$row = $this->accountmaster->getGroupCode($group_id);
		if($row)
			$no = intval(preg_replace('/[^0-9]+/', '', $row->account_id), 10);
		else 
			$no = 0;
		
		$no++;
		return $code = strtoupper($group->code).''.$no;
		//return $group->account_id;

	}
	
	public function show($id) { 

		$data = array();
		$acmasterrow = $this->accountmaster->accountMasterView($id);
		//echo '<pre>';print_r($acmasterrow);exit;
		return view('body.accountmaster.view')
					->withMasterrow($acmasterrow)
					->withData($data);
	}
	
	public function getCustomer()
	{
		$data = array();
		$customers = $this->accountmaster->getCustomerList();//print_r($customers);exit;
		return view('body.customerenquiry.customer')
					->withCustomers($customers)
					->withData($data);
	}
	
	public function getSalesman()
	{
		$data = array();
		$salesmans = $this->salesman->getSalesmanList();
		return view('body.customerenquiry.salesman')
					->withSalesmans($salesmans)
					->withData($data);
	}
	
	public function getItem($num)
	{
		$data = array();
		$itemmaster = $this->itemmaster->getActiveItemmasterList();
		return view('body.customerenquiry.item')
					->withItems($itemmaster)
					->withNum($num)
					->withData($data);
	}
	
	public function getEnquiry($customer_id, $url)
	{
		$data = array();
		$enquiry = $this->customer_enquiry->getCustomerEnquiry($customer_id);//print_r($quotations);exit;
		return view('body.customerenquiry.enquiry')
					->withEnqs($enquiry)
					->withUrl($url)
					->withData($data);
	}
	
	public function getItemDetails($id) 
	{
		$data = array();
		$items = $this->customer_enquiry->getItems(array($id));
		return view('body.customerenquiry.itemdetails')
					->withItems($items)
					->withData($data);
	}
	
	public function getPrint($id,$fc=null)
	{
		$attributes['document_id'] = $id;
		$attributes['is_fc'] = ($fc)?1:'';
		$result = $this->customer_enquiry->getQuotation($attributes);
		$itemdesc = $this->makeTreeArr($this->customer_enquiry->getItemDesc($id));//echo '<pre>';print_r($result['details']);exit;
		$titles = ['main_head' => 'Customer Enquiry','subhead' => 'Customer Enquiry'];
		return view('body.customerenquiry.print')
					->withDetails($result['details'])
					->withTitles($titles)
					->withFc($attributes['is_fc'])
					->withItemdesc($itemdesc)
					->withItems($result['items']);
		
	}
	
	protected function makeTreeItm($result)
	{
		$childs = array();
		foreach($result as $item)
			$childs[$item['item_id']][] = $item;
		
		return $childs;
	}
	
	protected function makeTree($result)
	{
		$childs = array();
		foreach($result as $item)
			$childs[$item['voucher_no']][] = $item;
		
		return $childs;
	}
	
	protected function makeArrGroup($result)
	{
		$childs = array();
		foreach($result as $item)
			$childs[$item['voucher_no']][] = $item;
		
		$arr = array();
		foreach($childs as $child) {
			$pending_qty = $pending_amt = $vat_amount = $net_amount = $discount = 0;
			foreach($child as $row) {
			    $pending_qty = ($row->balance_quantity==0)?$row->quantity:$row->balance_quantity;
			    $pending_amt += $pending_qty * $row->unit_price;
				$vat = $row->unit_vat / $row->quantity;
				$vat_amount += $vat * $pending_qty;
				$net_amount = $vat_amount + $pending_amt;
				$voucher_no = $row->voucher_no;
				$refno = $row->reference_no;
				$suppname = $row->master_name;
				$salesman = $row->salesman;
				$discount = $row->discount;
			}
			$arr[] = ['voucher_no' => $voucher_no,'reference_no' => $refno, 'master_name' => $suppname, 'discount' => $discount, 
					  'total' => $pending_amt,'vat_amount' => $vat_amount, 'net_total' => $net_amount, 'salesman' => $salesman];
			
		}

		return $arr;
	}
	
		public function getJob($id)
	{
		$data = array();
	
			$data = DB::table('customer_enquiry')->where('customer_enquiry.customer_id',$id)
			                    ->join('jobmaster', 'jobmaster.id', '=', 'customer_enquiry.job_id')
			                   ->where('customer_enquiry.status',1)->where('customer_enquiry.deleted_at','0000-00-00 00:00:00')
			                   ->select('jobmaster.id','jobmaster.code')->orderBy('jobmaster.id', 'DESC')->get();
			return $data;
		}
	

	public function getSearch()
	{
		$data = array();
		$pending=(Input::get('pending'))?Input::get('pending'):0;
		$reports = $this->customer_enquiry->getPendingReport(Input::all());
		
		if(Input::get('search_type')=="summary"  && $pending==0)
			$voucher_head = 'Customer Enquiry Summary';
		elseif(Input::get('search_type')=="summary"  && $pending==1) {
			$voucher_head = 'Customer Enquiry Pending Summary';
			$reports = $this->makeArrGroup($reports);
		} elseif(Input::get('search_type')=="detail"  && $pending==0) {
			$voucher_head = 'Customer Enquiry Detail';
			$reports = $this->makeTree($reports);
		} elseif(Input::get('search_type')=="detail" && $pending==1 ) {
			$voucher_head = 'Customer Enquiry Pending Detail';
			$reports = $this->makeTree($reports);
		}
		
		//echo '<pre>';print_r($reports);exit;
		return view('body.customerenquiry.preprint')
					->withReports($reports)
					->withVoucherhead($voucher_head)
					->withType(Input::get('search_type'))
					->withFromdate(Input::get('date_from'))
					->withTodate(Input::get('date_to'))
					->withSalesman(Input::get('salesman'))
					->withSettings($this->acsettings)
					->withData($data);
	}
	
	
	public function dataExport()
	{
		$data = array();
		Input::merge(['type' => 'export']);
		$reports = $this->customer_enquiry->getPendingReport(Input::all());
		
		if(Input::get('search_type')=="summary")
			$voucher_head = 'Customer Enquiry Summary';
		elseif(Input::get('search_type')=="summary_pending") {
			$voucher_head = 'Customer Enquiry Pending Summary';
			$reports = $this->makeArrGroup($reports);
		} elseif(Input::get('search_type')=="detail") {
			$voucher_head = 'Customer Enquiry Detail';
		} else {
			$voucher_head = 'Customer Enquiry Pending Detail';
		}
		
		 //echo '<pre>';print_r($reports);exit;
		
		if(Input::get('search_type')=='detail' || Input::get('search_type')=='detail_pending') {
			
			$datareport[] = ['SI.No.','Qtn.#', 'Qtn.Ref#', 'Customer','Salesman','Item Code','Description','Qtn.Qty','Rate','Total Amt.'];
			$i=0;
			foreach ($reports as $row) {
				$i++;
				$datareport[] = [ 'si' => $i,
								  'po' => $row['voucher_no'], 
								  'ref' => $row['reference_no'],
								  'supplier' => $row['master_name'],
								  'salesman' => $row['salesman'],
								  'item_code' => $row['item_code'],
								  'description' => $row['description'],
								  'quantity' => $row['quantity'],
								  'unit_price' => $row['unit_price'],
								  'net_amount' => $row['net_total']
								];
			}
		} else {
			
			$datareport[] = ['SI.No.','Qtn.#', 'Qtn.Ref#', 'Customer','Salesman','Gross Amt.','VAT Amt.','Net Total'];
			$i=0;
			foreach ($reports as $row) {
					$i++;
					$datareport[] = [ 'si' => $i,
									  'po' => $row['voucher_no'],
									  'ref' => $row['reference_no'],
									  'supplier' => $row['master_name'],
									  'salesman' => $row['salesman'],
									  'gross' => $row['total'],
									  'vat' => $row['vat_amount'],
									  'total' => $row['net_total']
									];
			}
		}
		 //echo $voucher_head.'<pre>';print_r($datareport);exit;
		Excel::create($voucher_head, function($excel) use ($datareport,$voucher_head) {

        // Set the spreadsheet title, creator, and description
        $excel->setTitle($voucher_head);
        $excel->setCreator('NumakPro ERP')->setCompany(Session::get('company'));
        $excel->setDescription($voucher_head);

        // Build the spreadsheet, passing in the payments array
		$excel->sheet('sheet1', function($sheet) use ($datareport) {
			$sheet->fromArray($datareport, null, 'A1', false, false);
		});

		})->download('xlsx');
		
	}
	
	public function checkVchrNo() {

		$check = $this->customer_enquiry->check_voucher_no(Input::get('voucher_no'), Input::get('id'));
		$isAvailable = ($check) ? false : true;
		echo json_encode(array(
							'valid' => $isAvailable,
						));
	}
}


